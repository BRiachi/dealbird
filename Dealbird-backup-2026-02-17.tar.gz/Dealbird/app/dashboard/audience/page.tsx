import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { AudienceTable } from "./AudienceTable";

export default async function AudiencePage() {
    const session = await getServerSession(authOptions);
    if (!session?.user) redirect("/login");

    try {
        // Fetch all orders for this user
        const orders = await prisma.order.findMany({
            where: { userId: session.user.id, status: "PAID" },
            include: { product: true },
            orderBy: { createdAt: "desc" },
        });

        // Aggregate unique customers
        const customersMap = new Map<string, any>();

        orders.forEach((order) => {
            const email = order.buyerEmail;
            if (!email) return;

            if (!customersMap.has(email)) {
                customersMap.set(email, {
                    email,
                    name: order.buyerName || "Unknown",
                    totalSpend: 0,
                    orders: 0,
                    lastOrder: order.createdAt,
                    products: new Set(),
                });
            }

            const customer = customersMap.get(email);
            customer.totalSpend += order.amount;
            customer.orders += 1;
            customer.products.add(order.product.title);
            // Keep max date
            if (new Date(order.createdAt) > new Date(customer.lastOrder)) {
                customer.lastOrder = order.createdAt;
            }
        });

        const customers = Array.from(customersMap.values()).map(c => {
            // Safe conversions
            const productsList = Array.from(c.products).join(", ");
            const spend = c.totalSpend / 100;
            const dateStr = new Date(c.lastOrder).toISOString();

            return {
                email: c.email,
                name: c.name,
                totalSpend: spend,
                orders: c.orders,
                lastOrder: dateStr,
                products: productsList
            };
        });

        return (
            <div className="space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold">Audience</h1>
                        <p className="text-gray-500">Your customers and leads</p>
                    </div>
                </div>

                <AudienceTable data={customers} />
            </div>
        );
    } catch (e) {
        console.error("Audience Page Error:", e);
        return <div>Error loading audience: {String(e)}</div>;
    }
}
