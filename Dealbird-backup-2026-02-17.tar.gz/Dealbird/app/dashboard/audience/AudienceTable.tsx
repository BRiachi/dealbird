"use client";

import { useState } from "react";
import { downloadCSV } from "@/lib/utils";

interface Customer {
    email: string;
    name: string;
    totalSpend: number;
    orders: number;
    lastOrder: string;
    products: string;
}

export function AudienceTable({ data }: { data: Customer[] }) {
    const [search, setSearch] = useState("");

    const filtered = data.filter(c =>
        c.email.toLowerCase().includes(search.toLowerCase()) ||
        c.name.toLowerCase().includes(search.toLowerCase())
    );

    const handleExport = () => {
        downloadCSV(filtered, "dealbird-audience.csv");
    };

    return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50/50">
                <input
                    placeholder="Search customers..."
                    className="px-4 py-2 border rounded-lg bg-white text-sm w-64 focus:ring-2 focus:ring-black outline-none"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                <button
                    onClick={handleExport}
                    className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-bold hover:bg-gray-50 flex items-center gap-2"
                >
                    <span>⬇️</span> Export CSV
                </button>
            </div>

            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="bg-gray-50 text-gray-500 uppercase font-bold text-xs">
                        <tr>
                            <th className="px-6 py-3">Customer</th>
                            <th className="px-6 py-3">Total Spend</th>
                            <th className="px-6 py-3">Orders</th>
                            <th className="px-6 py-3">Last Seen</th>
                            <th className="px-6 py-3">Products</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {filtered.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-6 py-8 text-center text-gray-400">
                                    No customers found. Share your link to get sales!
                                </td>
                            </tr>
                        ) : (
                            filtered.map((c) => (
                                <tr key={c.email} className="hover:bg-gray-50/50 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="font-bold text-gray-900">{c.name}</div>
                                        <div className="text-gray-500 text-xs">{c.email}</div>
                                    </td>
                                    <td className="px-6 py-4 font-mono font-medium">
                                        ${c.totalSpend.toFixed(2)}
                                    </td>
                                    <td className="px-6 py-4">
                                        {c.orders}
                                    </td>
                                    <td className="px-6 py-4 text-gray-500">
                                        {new Date(c.lastOrder).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 max-w-xs truncate text-gray-500" title={c.products}>
                                        {c.products}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
            <div className="p-4 border-t bg-gray-50/50 text-xs text-center text-gray-400">
                Showing {filtered.length} customers
            </div>
        </div>
    );
}
