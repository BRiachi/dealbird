import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import ProductList from "./components/ProductList";

interface Props {
    params: { handle: string };
}

// Generate metadata
export async function generateMetadata({ params }: Props): Promise<Metadata> {
    const user = await prisma.user.findFirst({
        where: { handle: { equals: params.handle, mode: "insensitive" } },
    });

    if (!user) return { title: "User Not Found" };

    return {
        title: `${user.name || user.handle} | DealBird`,
        description: user.bio || `Check out ${user.handle}'s store on DealBird.`,
        openGraph: {
            images: user.avatar || user.image || [],
        },
    };
}

export default async function PublicStorePage({ params }: Props) {
    // Fetch user and products
    const user = await prisma.user.findFirst({
        where: { handle: { equals: params.handle, mode: "insensitive" } },
        include: {
            products: {
                where: { archived: false },
                orderBy: { order: "asc" },
            },
        },
    });

    if (!user) notFound();

    // Basic theming
    const bgStyle = user.theme === "dark"
        ? "bg-black text-white"
        : "bg-gray-50 text-black";

    return (
        <div className={`min-h-screen flex flex-col ${bgStyle}`}>
            <main className="flex-1 w-full max-w-md mx-auto px-6 py-12">

                {/* Profile Header */}
                <div className="flex flex-col items-center text-center mb-10">
                    <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-white shadow-sm bg-gray-200">
                        {user.avatar || user.image ? (
                            <img
                                src={user.avatar || user.image!}
                                alt={user.name || user.handle || "User"}
                                className="w-full h-full object-cover"
                            />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#C8FF00] to-[#ABDB00] text-3xl font-bold text-black/50">
                                {(user.name || user.handle || "U")[0].toUpperCase()}
                            </div>
                        )}
                    </div>

                    <h1 className="text-xl font-bold tracking-tight mb-2">
                        @{user.handle}
                    </h1>

                    {user.bio && (
                        <p className="text-sm opacity-80 leading-relaxed max-w-xs mx-auto whitespace-pre-wrap">
                            {user.bio}
                        </p>
                    )}
                </div>

                {/* Products List */}
                <ProductList products={user.products} username={user.handle || ""} />

                {/* Footer */}
                <div className="mt-16 text-center">
                    <a href="/" className="inline-flex items-center gap-2 opacity-50 hover:opacity-100 transition-opacity">
                        <span className="text-xs font-bold uppercase tracking-widest">Powered by</span>
                        <span className="font-extrabold text-sm flex items-center gap-1">
                            <img src="/logo.png" className="w-4 h-4 rounded-sm" /> DealBird
                        </span>
                    </a>
                </div>

            </main>
        </div>
    );
}
