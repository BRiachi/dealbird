"use client";

import { useState } from "react";
import CheckoutModal from "./CheckoutModal";

interface Product {
    id: string;
    type: string;
    title: string;
    subtitle?: string | null;
    price: number;
    image?: string | null;
    settings?: any;
    order: number;
    archived: boolean;
}

interface Props {
    products: Product[];
    username: string; // for analytics or context
}

export default function ProductList({ products }: Props) {
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    const handleBuy = (product: Product) => {
        setSelectedProduct(product);
    };

    // Helper to find bump product
    const getBumpProduct = (product: Product) => {
        const bumpId = product.settings?.orderBump?.active ? product.settings?.orderBump?.productId : null;
        if (!bumpId) return null;
        return products.find(p => p.id === bumpId);
    };

    return (
        <div className="space-y-4">
            {products.map((product) => {
                if (product.type === "URL") {
                    const url = product.settings?.url || "#";
                    return (
                        <a
                            key={product.id}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full p-4 rounded-xl border bg-white border-gray-200 text-black hover:scale-[1.02] shadow-sm text-center font-bold transition-transform"
                        >
                            {product.title}
                        </a>
                    );
                }

                // Render Card for Digital / Coaching / Course
                const price = product.price; // or discount logic
                const discountPrice = product.settings?.discountPrice;
                const hasDiscount = discountPrice && discountPrice < price;

                return (
                    <div key={product.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                        {product.image && (
                            <div className="h-40 bg-gray-100 w-full overflow-hidden">
                                <img src={product.image} className="w-full h-full object-cover" alt={product.title} />
                            </div>
                        )}

                        <div className="p-5">
                            <div className="flex items-start justify-between mb-2">
                                <div>
                                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 block">
                                        {product.type === "DIGITAL" ? "Digital Download" :
                                            product.type === "COACHING" ? "Coaching Call" :
                                                product.type === "COURSE" ? "Course" : "Product"}
                                    </span>
                                    <h3 className="font-bold text-lg leading-tight">{product.title}</h3>
                                </div>
                                {price > 0 && (
                                    <div className="bg-gray-100 px-2 py-1 rounded-lg font-bold text-sm">
                                        {hasDiscount ? (
                                            <>
                                                <span className="text-red-600">${discountPrice / 100}</span>
                                                <span className="line-through opacity-50 ml-1 text-xs">${price / 100}</span>
                                            </>
                                        ) : (
                                            <span>${price / 100}</span>
                                        )}
                                    </div>
                                )}
                            </div>

                            {product.subtitle && (
                                <p className="text-sm text-gray-500 mb-4 line-clamp-2">{product.subtitle}</p>
                            )}

                            <button
                                onClick={() => handleBuy(product)}
                                className="w-full py-3 bg-black text-white font-bold rounded-xl hover:bg-gray-800 transition-colors flex items-center justify-center gap-2"
                            >
                                {product.settings?.buttonText || (product.type === "DIGITAL" ? "Download Now" : "Book Call")}
                                {product.settings?.duration && (
                                    <span className="text-xs font-normal opacity-70">
                                        • {product.settings.duration} min
                                    </span>
                                )}
                            </button>
                        </div>
                    </div>
                );
            })}

            {/* Modal */}
            {selectedProduct && (
                <CheckoutModal
                    product={selectedProduct}
                    bumpProduct={getBumpProduct(selectedProduct)}
                    isOpen={!!selectedProduct}
                    onClose={() => setSelectedProduct(null)}
                />
            )}
        </div>
    );
}
